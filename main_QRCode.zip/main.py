import json
import qrcode
import qrcode.image.svg
from pathlib import Path
import re

BASE_URL = "https://map-bcsir.srcdrive.com/?buildingid="
OUTPUT_DIR = Path("qr_svg_output")
INPUT_FILE = "buildingIDmapping.json"

def sanitize_filename(name):
    """Replace unsafe filename characters with underscores."""
    return re.sub(r'[^\w\-_\. ]', '_', name)

def generate_qr_svg(link: str, filename: str):
    factory = qrcode.image.svg.SvgImage
    img = qrcode.make(link, image_factory=factory)
    
    file_path = OUTPUT_DIR / f"{filename}.svg"
    with open(file_path, 'wb') as f:
        img.save(f)
    return file_path

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        locations = json.load(f)

    for item in locations:
        link = f"{BASE_URL}{item['id']}"
        safe_filename = sanitize_filename(item['name'])
        svg_path = generate_qr_svg(link, safe_filename)
        print(f"QR saved: {svg_path}")

if __name__ == "__main__":
    main()
